


#install mysql.connector libray 



# !pip install mysql.connector


# # connect MySQL database using python


#import mysql connector library for mysql database
import mysql.connector




#create connection object for database 
conn_object=mysql.connector.connect(host="localhost",user="root",password="")




#create cursor for executing query
db_cursor = conn_object.cursor()




#create database
db_cursor.execute("CREATE DATABASE flight;")





#import spark session
import pyspark
from pyspark.sql import SparkSession
spark = SparkSession.builder.config("spark.jars", "mysql-connector-java-8.0.28.jar").master("local").appName("PySpark_MySQL").getOrCreate()



#create pyspark dataframe
AirlineDF = spark.read.option("header", "true").csv("airlines1.csv")




AirlineDF.show(5)




AirlineDF5 = AirlineDF.select("_c0","Year","Quarter", "Month", "DayofMonth", "DayofWeek","FlightDate","Reporting_Airline","DOT_ID_Reporting_Airline","OriginCityName" , "OriginState", "OriginStateFips", "OriginStateName","Distance" , "DistanceGroup","CarrierDelay","WeatherDelay", "NASDelay")




AirlineDF5.show(5)


# # Write data from pyspark dataframe to Mysql Database
# 



AirlineDF5.write.format('jdbc').options(
      url='jdbc:mysql://localhost:3306/flight',
      driver='com.mysql.jdbc.Driver',
      dbtable='Airline',
      user='root',
      password='').mode('append').save()


# # Read data form Mysql using Pyspark



AirDF = spark.read.format("jdbc").option("url", "jdbc:mysql://localhost:3306/demodb5").option("driver", "com.mysql.jdbc.Driver").option("dbtable", "Airline").option("user", "root").option("password", "").load()




AirDF.show()




AirDF.select("OriginStateName").groupby("OriginStateName").count().show()




