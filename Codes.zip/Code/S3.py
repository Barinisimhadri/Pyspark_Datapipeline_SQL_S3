# !pip install pyspark



# !pip install findspark



import os
os.environ['PYSPARK_SUBMIT_ARGS'] = "--packages=org.apache.hadoop:hadoop-aws:2.7.3 pyspark-shell"




# to be uncommented when running script
# import findspark
# findspark.init()



from pyspark.sql import SparkSession



# defeining the access keys
access_id =  ""
access_key = ""


# ## Setting up the configurations


# sc.stop()




# To create SparkContext
# from pyspark import SparkContext
import pyspark

sc=pyspark.SparkContext()

hadoop_conf=sc._jsc.hadoopConfiguration()




hadoop_conf.set("fs.s3a.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
hadoop_conf.set("fs.s3a.awsAccessKeyId", access_id)
hadoop_conf.set("fs.s3a.awsSecretAccessKey", access_key)
hadoop_conf.set("fs.s3.buffer.dir", "${hadoop.tmp.dir}/s3")
hadoop_conf.set("fs.s3a.buffer.dir", "${hadoop.tmp.dir}/s3a")


# ## Extract Layer



df=sc.textFile("s3a://airlines123/airline/airlines1.csv")




df.collect()


# ## Transform Layer



Ardd = df.map(lambda x: x.replace(', ',' ').split(','))



AirlineRdd=Ardd.map(lambda x: Row(Year=x[1],FlightDate=x[6]))


# ### Converting RDD to Dataframe



from pyspark import SQLContext
from pyspark.sql import Row



# setting up the sql context
sqlContex = SQLContext(sc)



AirlineDf = sqlContex.createDataFrame(AirlineRdd)




# seleting the years
AirlineDf.select('Year','FlightDate').show()




# How many flights are running each year
AirlineDf.select('Year').groupBy("Year").count().show()




#convert dataframe into Rdds
rdds = AirlineDf.rdd




rdds.collect()


# ## Loading Layer



rdds.repartition(1).saveAsTextFile("s3a://airlines123/testsample/report")